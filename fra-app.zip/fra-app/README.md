# 🔥 Fire Risk Assessment App

Interactieve brandveiligheid inspectie-tool met persistente opslag.

## Functies
- 8 categorieën met 36 inspectie-items
- Score (1–5) en conditie per item
- Opmerkingen/acties per item
- Automatische opslag in de browser (localStorage)
- Samenvatting met kritieke bevindingen
- Reset-functie

---

## 🚀 Deployen via Vercel (gratis)

### Optie A — via Vercel website (aanbevolen, geen terminal nodig)

1. Maak een gratis account op [vercel.com](https://vercel.com)
2. Maak een gratis account op [github.com](https://github.com)
3. Maak een nieuw GitHub-repository aan en upload alle bestanden uit deze map
4. Ga naar [vercel.com/new](https://vercel.com/new)
5. Klik **"Import Git Repository"** en selecteer jouw repo
6. Vercel detecteert Vite automatisch — klik **Deploy**
7. Na ~1 minuut krijg je een live URL zoals `https://fire-risk-assessment.vercel.app`

### Optie B — via terminal (Vercel CLI)

```bash
# Installeer Node.js via https://nodejs.org als je dat nog niet hebt

# Installeer Vercel CLI
npm install -g vercel

# Ga naar de projectmap
cd fra-app

# Installeer dependencies
npm install

# Login bij Vercel
vercel login

# Deploy
vercel --prod
```

---

## Lokaal draaien (voor testen)

```bash
cd fra-app
npm install
npm run dev
# Open http://localhost:5173
```

---

## Persistente opslag

Alle data wordt automatisch opgeslagen in `localStorage` van de browser.
- Data blijft bewaard bij het sluiten/herladen van de pagina
- Data is per browser/apparaat (niet gesynchroniseerd tussen apparaten)
- Gebruik de **Reset**-knop om alles te wissen

---

## Projectstructuur

```
fra-app/
├── index.html
├── package.json
├── vite.config.js
├── vercel.json
└── src/
    ├── main.jsx          # Entry point
    ├── App.jsx           # Hoofdcomponent + localStorage
    ├── Summary.jsx       # Samenvatting-scherm
    ├── data.js           # Categorieën en items
    ├── useLocalStorage.js# Storage hook
    └── index.css         # Global styles
```
